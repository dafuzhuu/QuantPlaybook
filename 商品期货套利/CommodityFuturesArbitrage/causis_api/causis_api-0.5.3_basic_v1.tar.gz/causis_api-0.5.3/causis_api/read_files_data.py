import json
from symtable import Symbol
import pandas as pd
import datetime as dt
from dateutil.relativedelta import relativedelta
import os
from sympy import python
import requests
import calendar
from causis_api.common_data import *
import concurrent.futures
# url_get="http://192.168.1.120:1225/"
parquet_path="P:/parquet/"
parquet_path_2="Q:/parquet/"


def _get_months_between_dates(start_date: str, end_date: str)->list:
    '''
    返回两个日期间的年月list, "YYYYMM"
    '''
    # 将日期字符串转换为日期对象
    start_date = dt.strptime(start_date, "%Y-%m-%d")
    end_date = dt.strptime(end_date, "%Y-%m-%d")
    
    # 确保开始日期早于或等于结束日期
    if start_date > end_date:
        start_date, end_date = end_date, start_date
    
    # 初始化结果列表
    months = []
    
    # 获取起始日期的年份和月份
    current_year = start_date.year
    current_month = start_date.month
    
    # 循环遍历每个月，直到结束日期
    while (current_year, current_month) <= (end_date.year, end_date.month):
        # 将年份和月份添加到结果列表
        months.append((current_year, current_month))
        
        # 获取下一个月的年份和月份
        if current_month == 12:
            current_year += 1
            current_month = 1
        else:
            current_month += 1
    return [f"{year}{month:02d}" for (year, month) in months]



def get_data_file(symbol,begin,end,type,read_file="month"):
    """
    通过文件读取高频数据
    symbol:标的
    begin:开始日期
    end:结束日期
    type:数据类型 tick trader order    
    read_file:读取文件 默认为month读取月文件;如为day读取日文件    
    """
    if read_file=="day":
        return _get_data_file_day(symbol,begin,end,type)
    start_date = dt.datetime.strptime(begin, '%Y-%m-%d')
    end_date = dt.datetime.strptime(end, '%Y-%m-%d')
    end_date = end_date + relativedelta(days=1)
    end=end_date.strftime('%Y-%m-%d')
    if end_date<=start_date:
        print("error: end_date<start_date")
        return
    # 需要读取的月份数据
    months = []
    current_month = start_date
    # 获取结束日期当月最后一天
    _, last_day = calendar.monthrange(end_date.year, end_date.month)
    last_dt = dt.datetime(end_date.year, end_date.month, last_day)
    while current_month <= last_dt:
        months.append(current_month.strftime('%Y%m'))
        current_month += relativedelta(months=1)
    
    read_path=f"{parquet_path}stock_L2/{type}"
    read_path_2=f"{parquet_path_2}stock_L2/{type}"
    temp_name=symbol.replace(".","_")
    file_name=f"{temp_name}.parquet"
    df= pd.DataFrame()
    for item in months:
        file_path=f"{read_path}/{item}/{file_name}"
        if os.path.isfile(file_path):
            temp_df=pd.read_parquet(file_path,engine='pyarrow')
            if len(temp_df)>0:
                df=pd.concat([df,temp_df],axis=0)
        else:
            # 如果第一路径没有，就去第二路径找
            file_path=f"{read_path_2}/{item}/{file_name}"
            if os.path.isfile(file_path):
                temp_df=pd.read_parquet(file_path,engine='pyarrow')
                if len(temp_df)>0:
                    df=pd.concat([df,temp_df],axis=0)
    if df.shape[0]==0:
        print("error: df is null")
        return df   
    df=df[df["time"]>=begin]
    df=df[df["time"]<=end]
    return df.reset_index(drop=True)

def get_data_file_thread(symbol,begin,end,type,read_file="month"):
    """
    通过文件读取高频数据
    symbol:标的
    begin:开始日期
    end:结束日期
    type:数据类型 tick trader order    
    read_file:读取文件 默认为month读取月文件;如为day读取日文件    
    """
    if read_file=="day":
        # return _get_data_file_day(symbol,begin,end,type)
        return _get_data_file_day_thread(symbol,begin,end,type)
    start_date = dt.datetime.strptime(begin, '%Y-%m-%d')
    end_date = dt.datetime.strptime(end, '%Y-%m-%d')
    end_date = end_date + relativedelta(days=1)
    end=end_date.strftime('%Y-%m-%d')
    if end_date<=start_date:
        print("error: end_date<start_date")
        return
    # 需要读取的月份数据
    months = []
    current_month = start_date
    # 获取结束日期当月最后一天
    _, last_day = calendar.monthrange(end_date.year, end_date.month)
    last_dt = dt.datetime(end_date.year, end_date.month, last_day)
    while current_month <= last_dt:
        months.append(current_month.strftime('%Y%m'))
        current_month += relativedelta(months=1)
    
    read_path=f"{parquet_path}stock_L2/{type}"
    read_path_2=f"{parquet_path_2}stock_L2/{type}"
    temp_name=symbol.replace(".","_")
    file_name=f"{temp_name}.parquet"
    df= pd.DataFrame()
    for item in months:
        file_path=f"{read_path}/{item}/{file_name}"
        if os.path.isfile(file_path):
            temp_df=pd.read_parquet(file_path,engine='pyarrow')
            if len(temp_df)>0:
                df=pd.concat([df,temp_df],axis=0)
        else:
            # 如果第一路径没有，就去第二路径找
            file_path=f"{read_path_2}/{item}/{file_name}"
            if os.path.isfile(file_path):
                temp_df=pd.read_parquet(file_path,engine='pyarrow')
                if len(temp_df)>0:
                    df=pd.concat([df,temp_df],axis=0)
    if df.shape[0]==0:
        print("error: df is null")
        return df   
    df=df[df["time"]>=begin]
    df=df[df["time"]<=end]
    return df.reset_index(drop=True)




def get_min_file(symbol,begin,end,type):
    """
    通过文件读取分钟行情数据
    symbol:标的
    begin:开始日期
    end:结束日期
    type:数据类型 1min 5min 30min    
    """
    end_date = dt.datetime.strptime(end, '%Y-%m-%d')
    end_date = end_date + relativedelta(days=1)
    end=end_date.strftime('%Y-%m-%d')
        
    symbol_type="stock_min/"    
    if symbol.startswith("F"):
        symbol_type="future_min/"
        
    read_path=f"{parquet_path}{symbol_type}{type}"
    read_path_2=f"{parquet_path_2}{symbol_type}{type}"
    temp_name=symbol.replace(".","_")
    file_name=f"{temp_name}.parquet"
    df= pd.DataFrame()
    file_path=f"{read_path}/{file_name}"
    if os.path.isfile(file_path):
        temp_df=pd.read_parquet(file_path,engine='pyarrow')
        if len(temp_df)>0:
            df=pd.concat([df,temp_df],axis=0)
    else:
        # 如果第一路径没有，就去第二路径找
        file_path=f"{read_path_2}/{file_name}"
        if os.path.isfile(file_path):
            temp_df=pd.read_parquet(file_path,engine='pyarrow')
            if len(temp_df)>0:
                df=pd.concat([df,temp_df],axis=0)    
    df=df[df["CLOCK"]>=begin]
    df=df[df["CLOCK"]<=end]
    return df




def _get_data_file_day(symbol,begin,end,type):
    """
    通过文件读取高频数据(日为单位读取)
    symbol:标的
    begin:开始日期
    end:结束日期
    type:数据类型 tick trader order    
    """
    trd_date= get_trading_dates(begin,end)
    start_date = dt.datetime.strptime(begin, '%Y-%m-%d')
    end_date = dt.datetime.strptime(end, '%Y-%m-%d')
    end_date = end_date + relativedelta(days=1)
    end=end_date.strftime('%Y-%m-%d')
    if end_date<=start_date:
        print("error: end_date<start_date")
        return
    read_path=f"{parquet_path}stock_L2/{type}"
    read_path_2=f"{parquet_path_2}stock_L2/{type}"
    temp_name=symbol.replace(".","_")
    file_name=f"{temp_name}.parquet"
    df= pd.DataFrame()
    for item in trd_date:
        #20230501    
        item=item.replace("-","")
        file_path=f"{read_path}/{item}/{file_name}"
        if os.path.isfile(file_path):
            temp_df=pd.read_parquet(file_path,engine='pyarrow')
            if len(temp_df)>0:
                df=pd.concat([df,temp_df],axis=0)
        else:
            # 如果第一路径没有，就去第二路径找
            file_path=f"{read_path_2}/{item}/{file_name}"
            if os.path.isfile(file_path):
                temp_df=pd.read_parquet(file_path,engine='pyarrow')
                if len(temp_df)>0:
                    df=pd.concat([df,temp_df],axis=0)
    if df.shape[0]==0:
        print("error: df is null")
        return df   
    df=df[df["time"]>=begin]
    df=df[df["time"]<=end]
    return df.reset_index(drop=True)


def _get_data_file_day_thread(symbol,begin,end,type):
    """
    通过文件读取高频数据(日为单位读取)
    symbol:标的
    begin:开始日期
    end:结束日期
    type:数据类型 tick trader order    
    """
    trd_date= get_trading_dates(begin,end)
    start_date = dt.datetime.strptime(begin, '%Y-%m-%d')
    end_date = dt.datetime.strptime(end, '%Y-%m-%d')
    end_date = end_date + relativedelta(days=1)
    end=end_date.strftime('%Y-%m-%d')
    if end_date<=start_date:
        print("error: end_date<start_date")
        return
    read_path=f"{parquet_path}stock_L2/{type}"
    read_path_2=f"{parquet_path_2}stock_L2/{type}"
    
    temp_name=symbol.replace(".","_")
    file_name=f"{temp_name}.parquet"
    df= pd.DataFrame()
    parquet_files = []
    for item in trd_date:
        #20230501    
        item=item.replace("-","")
        file_path=f"{read_path}/{item}/{file_name}"
        if os.path.isfile(file_path):
            parquet_files.append(file_path)
            # temp_df=pd.read_parquet(file_path,engine='pyarrow')
            # if len(temp_df)>0:
            #     df=pd.concat([df,temp_df],axis=0)
        else:
            # 如果第一路径没有，就去第二路径找
            file_path=f"{read_path_2}/{item}/{file_name}"
            if os.path.isfile(file_path):
                parquet_files.append(file_path)
                # temp_df=pd.read_parquet(file_path,engine='pyarrow')
                # if len(temp_df)>0:
                #     df=pd.concat([df,temp_df],axis=0)
    with concurrent.futures.ThreadPoolExecutor() as executor:
    # 使用map函数并行读取Parquet文件
        results = list(executor.map(read_parquet, parquet_files))
    results = [x for x in results if x is not None]
    if len(results)==0:
        return None
    df=pd.concat(results).reset_index(drop=True)
    # for temp in results:
    #     # print(temp.head())
    #     if temp.shape[0]>0: 
    #         df=pd.concat([df, temp])
    if df.shape[0]==0:
        print("error: df is null")
        return df   
    df=df[df["time"]>=begin]
    df=df[df["time"]<=end]
    return df.reset_index(drop=True)

def read_parquet(file_path):
    return pd.read_parquet(file_path)