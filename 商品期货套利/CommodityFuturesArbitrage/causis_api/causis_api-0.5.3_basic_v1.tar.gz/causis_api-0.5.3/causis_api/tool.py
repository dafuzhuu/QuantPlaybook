#从服务器提取原始数据
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)

import numpy as np
import pandas as pd
import matplotlib.pylab as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
from causis_api.common_data import get_trading_dates
from causis_api.common_data import get_price
from causis_api.common_data import all_instruments
from causis_api.common_data import get_previous_trading_date
from causis_api.stock_data import get_stock_valuation
from scipy.optimize import minimize

def DrawdownOverlapAnalysis(NetValueSeries,StrategyName="New_Strategy",test=None,draw_down=-0.05):
    '''
    作者：谭博文
    新策略与已有策略的相关性分析、回撤期分析、回撤重合度分析
    NetValueSeries：新策略的净值序列，格式为Series，index为日期序列
    StrategyName：新策略的名称
    test: 已有策略的相关数据，这个在AM-本地数据下载-策略回测中，初始版本文件为Balance-20210719.csv
    draw_down: 回撤平台期的阈值
    引用示例：
    data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\ATBW011.csv")
    data.index = pd.to_datetime(data.level_0)
    test_data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\Balance-20210719.csv")
    result = DrawdownOverlapAnalysis(data.adj_result,StrategyName="ATBW011",test=test_data)
    '''

    if NetValueSeries is None:
        print('请输入新策略的净值数据，格式为Series，index为日期序列！')
        return

    if test is None:
        print('请在AM-本地数据下载-策略回测中下载已有策略的相关数据！')
        test = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\Balance-20210719.csv")
        return

    # 返回结果初始化
    class result(object):
        draw_down_platform = None #是否出在回撤平台期
        overlap_mat = None #策略回撤的重合度
        corr = None #策略之间的相关系数
        show = None #画图

    # test = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\Balance-20210719.csv")
    num = len(test.Portfolio.drop_duplicates()) #找到策略个数
    count = int(len(test)/num)
    fig = plt.figure(figsize=(20,10))
    plt.rcParams['font.sans-serif'] = ['SimHei']
    draw_down_platform = pd.DataFrame()
    # 原始策略
    for i in range(1,num+1):
        
        locals()["test"+str(i)] = test[count*(i-1):count*i][["Portfolio","Date","NetValue"]]
        
        temp_test = locals()["test"+str(i)]


        temp_test["MaxNetValue"] = temp_test.NetValue.cummax()
        temp_test["Diff"] = temp_test["NetValue"]-temp_test["MaxNetValue"]
        temp_test["dummy"] = temp_test["Diff"].apply(lambda x: 1 if x<=draw_down else 0)

        temp_list = temp_test[temp_test.dummy==1].index.to_list()
        for j in temp_list:
            while j>=1:
                if temp_test.loc[j-1,"Diff"]<0 and temp_test.loc[j-1,"dummy"]==0:
                    temp_test.loc[j-1,"dummy"]=1
                    j=j-1
                else:
                    break

        for j in temp_list:
            while j<len(temp_list)-1:
                if temp_test.loc[j+1,"Diff"]<0 and temp_test.loc[j+1,"dummy"]==0:
                    temp_test.loc[j+1,"dummy"]=1
                    j=j+1
                else:
                    break

        temp_test.index = pd.to_datetime(temp_test.Date)
        locals()["test"+str(i)] = temp_test
        
        plt.bar(locals()["test"+str(i)].index,locals()["test"+str(i)].dummy,label=locals()["test"+str(i)].Portfolio[0],alpha=0.75,bottom=i-1,width=2)
        
        draw_down_platform[locals()["test"+str(i)].Portfolio[0]] = locals()["test"+str(i)].dummy
        
        
        
    # 新输入策略
    
    new_data = pd.DataFrame(NetValueSeries)
    new_data = new_data.rename(columns={new_data.columns[0]:"NetValue"})
    new_data = new_data.resample("1D").ffill()
    new_data["Date"] = new_data.index
    new_data.index = range(len(new_data))
    temp_test = new_data

    temp_test["MaxNetValue"] = temp_test.NetValue.cummax()
    temp_test["Diff"] = temp_test["NetValue"]-temp_test["MaxNetValue"]
    temp_test["dummy"] = temp_test["Diff"].apply(lambda x: 1 if x<=draw_down else 0)

    temp_list = temp_test[temp_test.dummy==1].index.to_list()
    for j in temp_list:
        while j>=1:
            if temp_test.loc[j-1,"Diff"]<0 and temp_test.loc[j-1,"dummy"]==0:
                temp_test.loc[j-1,"dummy"]=1
                j=j-1
            else:
                break

    for j in temp_list:
        while j<len(temp_list)-1:
            if temp_test.loc[j+1,"Diff"]<0 and temp_test.loc[j+1,"dummy"]==0:
                temp_test.loc[j+1,"dummy"]=1
                j=j+1
            else:
                break

    temp_test.index = pd.to_datetime(temp_test.Date)
    new_data = temp_test

    plt.bar(new_data.index,new_data.dummy,label=StrategyName,alpha=0.75,bottom=num,width=2)
    draw_down_platform[StrategyName] = new_data.dummy

        
    ax = fig.add_subplot(1,1,1)
    ax.set_title("回撤平台期",fontsize=15)
        
    plt.xticks(fontsize=15)
    plt.yticks(fontsize=15)    
    plt.legend(loc="upper left",fontsize=10)
    
    # plt.show()
    result.draw_down_platform = draw_down_platform
    
    # 生成回撤重合度
    port_list = []
    for i in range(1,num+1):
        port_list.append((locals()["test"+str(i)]).Portfolio[0])
        
    port_list.append(StrategyName)
    
    overlap_mat = pd.DataFrame(index=port_list,columns=port_list)
    for i in range(1,num+2):
        for j in range(1,num+2):
            if i<num+1:
                name1  = locals()["test"+str(i)]
            else:
                name1  = new_data
                
            if j<num+1:
                name2  = locals()["test"+str(j)]
            else:
                name2  = new_data
                
            date_list = name1.index & name2.index
            name1 = name1.loc[date_list]
            name2 = name2.loc[date_list]
            
            if len(name1.dummy[name1.dummy==1]) > 0:
                temp_value = len(name1.dummy[name1.dummy==1][name2.dummy==1])/len(name1.dummy[name1.dummy==1])
            else:
                # warnings.warn('策略没有出现最大回撤！')
                print('策略没有出现最大回撤！')
                temp_value = 0
                
            overlap_mat.iloc[i-1,j-1] = temp_value

    overlap_mat = overlap_mat.astype(np.float64)
    f, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(overlap_mat,annot=True,center=0.5,cmap="rainbow",linewidths=1,fmt='.3g', annot_kws={"size":15},square=True,cbar_kws={"shrink": 0.75})
    ax.tick_params(labelsize=12)
    ax.set_title("回撤重合度",fontsize=15)
    ax.set_yticklabels(labels=port_list,rotation=0)
    ax.set_xticklabels(labels=port_list,rotation=90)
    plt.tight_layout()
    # plt.show() 
    result.overlap_mat = overlap_mat
    
    
    # 生成收益率相关系数
    new_data = pd.DataFrame(NetValueSeries)
    new_data = new_data.rename(columns={new_data.columns[0]:"NetValue"})
    sum_result = pd.DataFrame(new_data.NetValue)
    sum_result = sum_result.rename(columns={"NetValue":StrategyName})

    for i in range(1,num+1):
        sum_result = sum_result.join(locals()["test"+str(i)].NetValue,how="inner")
        sum_result = sum_result.rename(columns={"NetValue":locals()["test"+str(i)].Portfolio[0]})

    sum_result = sum_result.diff().fillna(0)

    f, ax = plt.subplots(figsize=(12, 10))
    corr = sum_result.corr()
    sns.heatmap(corr,annot=True,center=0.5,cmap="rainbow",linewidths=1,fmt='.3g', annot_kws={"size":15},square=True,cbar_kws={"shrink": 0.75})
    ax.tick_params(labelsize=15)
    ax.set_title("收益率相关性",fontsize=15)
    plt.tight_layout()

    result.corr = corr
    result.show = plt.show
    # plt.show()    

    return result

def dynamic_leverage(pnl,initCap=1e7,destStdDev=0.1,limitPct=1e-4,shortBack=60,longBack=250,minCount=12):
    '''
    动态杠杆调整
    pnl:净值曲线，格式为Series
    destStdDev:目标波动率（年化）
    limitPct:日收益率阈值
    shortBack:最小回看周期
    longBack:最大回看周期
    minCount:最小有效数据个数
    输出：杠杆率、修正以后的净值曲线
    '''
    # 返回结果初始化
    class result(object):
        leverage = None #动态调整的杠杆率
        pnl = None #修正以后的pnl
        show = None #画图

    balance = pnl.copy(deep=True)
    balance.index = pd.to_datetime(balance.index)
    start_time = str(balance.index[0])[:10]
    end_time = str(balance.index[-1])[:10]
    trade_date = get_trading_dates(start_time,end_time)
    balance = balance.loc[trade_date]#取交易日的部分
    balance = balance / initCap
    pct_change = balance.diff()
    pct_change = pct_change.apply(lambda x: x if abs(x)>limitPct else np.nan)
    leverage = pd.Series()
    for idx,date in enumerate(pct_change.index):
        # if str(date)[:10] == '2018-03-01':
        #     break
        if idx < shortBack:
            leverage.loc[idx] = 1
        elif (idx >= shortBack) & (idx < longBack):
            if len(pct_change.iloc[:idx].dropna()) < minCount:
                leverage.loc[idx] = 1
            else:
                leverage.loc[idx] = destStdDev / pct_change.iloc[:idx].dropna().std() / np.sqrt(250)
        else:
            if len(pct_change.iloc[idx-shortBack:idx].dropna()) < minCount:
                if len(pct_change.iloc[idx-longBack:idx].dropna()) < minCount:
                    leverage.loc[idx] = 0
                else:
                    leverage.loc[idx] = destStdDev / pct_change.iloc[idx-longBack:idx].dropna().iloc[-minCount:].std() / np.sqrt(250)
            else:
                leverage.loc[idx] = destStdDev / pct_change.iloc[idx-shortBack:idx].dropna().std() / np.sqrt(250)
    leverage = leverage.apply(lambda x: x if x<=5 else 5)#杠杆率最大为5
    leverage.index = pct_change.index
    pct_fix = pct_change.fillna(0)
    pct_fix = leverage * pct_fix
    pnl_fix = pct_fix.cumsum() + 1
    #画图
    fig = plt.figure(figsize=(12, 10))
    ax = fig.subplots()
    ax.set_ylabel('Net_value')#, fontdict={'family' : 'Times New Roman', 'size' : 16}
    ax.plot(balance,'b',label='ori_pnl')
    ax.plot(pnl_fix,'r',label='fix_pnl')
    ax.legend(['ori_pnl','fix_pnl'],loc='upper left')#,prop={'family' : 'Times New Roman', 'size':16}
    ax2 = ax.twinx()
    ax2.set_ylabel('leverage')#, fontdict={'family' : 'Times New Roman', 'size' : 16}
    ax2.bar(leverage.index,leverage, facecolor='none', edgecolor='g',label='leverage')
    ax2.legend(['leverage'],loc='upper right')#,prop={'family' : 'Times New Roman', 'size':16}
    # ax.set_yticklabels(fontproperties = 'Times New Roman', size = 16) 
    # ax.set_xticklabels(fontproperties = 'Times New Roman', size = 16)

    result.leverage = leverage
    result.pnl = pnl_fix
    result.show = plt.show
    
    return result


class MVO(object):
    '''
    作者：许思军
    功能：航海家子策略权重分配优化模型
    '''

    def __init__(self, df_return, window=120, keep=1, init_weight=None, 
                 risk_averse=None, ewm=None):
        self.df_return = df_return
        self.window = window # 回看时间
        self.keep = keep # 保持时间             
        
        self.init_weight = init_weight #初始设置的权重
        
        self.risk_averse = risk_averse
        self.ewm = ewm

    def norm_preprocess(self, df_return, window=120, n_sigma=3):
        '''
        3sigma 数据极值预处理
        '''
        df_new_return = df_return.copy()
        for i in range(len(df_return)):
            if i >= window:
                mean = df_new_return.iloc[(i-window):i].mean()
                std = df_new_return.iloc[(i-window):i].std()
                mask1 = df_new_return.iloc[i] > (mean + n_sigma * std)
                mask2 = df_new_return.iloc[i] < (mean - n_sigma * std)
                df_new_return.iloc[i, mask1] = (mean + n_sigma * std)[mask1]
                df_new_return.iloc[i, mask2] = (mean - n_sigma * std)[mask2]    
        return df_new_return

    def get_constrain(self, prev_weight):
        '''
        权重的约束条件
        '''
        cons = (
            {'type': 'ineq', 'fun': lambda w: w},             
            # {'type': 'ineq', 'fun': lambda w: 0.4 - w},
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.},
            {'type': 'ineq', 'fun': lambda w: 0.1 - np.sum(np.absolute(w - prev_weight))},
            {'type': 'ineq', 'fun': lambda w: w[0] + w[1] + w[2] + w[3] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - (w[0] + w[1] + w[2] + w[3])}, 
            {'type': 'ineq', 'fun': lambda w: w[4] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - w[4]}, 
            {'type': 'ineq', 'fun': lambda w: w[5] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - w[5]}, 
            {'type': 'ineq', 'fun': lambda w: w[6] + w[7] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - (w[6] + w[7])}, 
            )
        return cons
            
    def get_daily_div_weight(self, w_return, prev_weight):   
        '''
        根据过去一段收益率序列给出子策略权重，利用最大分散 
        '''                   
        if self.ewm is None:
            std = w_return.std().values
            cov = w_return.cov().values
        else: ###使用指数加权平均进行协方差标准差估计
            cov = w_return.ewm(span=self.window, adjust=False).cov().values[-len(w_return.iloc[0]):]
            std = np.diagonal(cov)

        obj_func = lambda w: -np.dot(w, std) / np.sqrt(np.dot(np.dot(w, cov), w)) ## -1 * 分散度
        ## 权重限制
        cons = self.get_constrain(prev_weight=prev_weight)
        options = {'maxiter': 1000}
        res = minimize(obj_func, prev_weight, method='SLSQP', constraints=cons, options=options)
        return res.x    
    
    def get_daily_mvo_weight(self, w_return, prev_weight):        
        '''
        均值-方差优化
        '''
        if self.ewm is None:
            rt = w_return.mean().values
            cov = w_return.cov().values
        else:
            rt = w_return.ewm(span=self.window, adjust=False).mean().iloc[-1].values
            cov = w_return.ewm(span=self.window, adjust=False).cov().values[-len(rt):]

        obj_func = lambda w: -np.sum(w*rt) + 0.5 * self.risk_averse * np.dot(np.dot(w, cov), w) ## -1 * U(w)
        ## 权重限制
        cons = self.get_constrain(prev_weight=prev_weight)
        options = {'maxiter': 1000}
        res = minimize(obj_func, prev_weight, method='SLSQP', constraints=cons, options=options)
        return res.x      
    
    def get_weight(self):
        '''
        根据目标优化方法计算子策略权重序列
        '''
        df_weight = pd.DataFrame(1., index=self.df_return.index, columns=self.df_return.columns) #初始化子策略权重
        df_weight = df_weight * self.init_weight
        
        processed_return = self.norm_preprocess(self.df_return, window=self.window, n_sigma=3) #收益率序列预处理
            
        for i in range(len(self.df_return)):
            if i >= self.window: #当日期大于回看区间时，开始对权重进行调整，否则按照初始权重处理
                if (i - self.window) % self.keep == 0: # 开始调整日期                                        
                    w_return = processed_return.iloc[(i-self.window):i] #回看时间段的子策略收益率序列                    
                    w_return = w_return.rolling(self.keep).sum().dropna()
    
                    if self.risk_averse is not None:
                        daily_weight = self.get_daily_mvo_weight(w_return, df_weight.iloc[i-1])
                    else:                        
                        daily_weight = self.get_daily_div_weight(w_return, df_weight.iloc[i-1]) #计算得到子策略该日的权重                        
                        
                    df_weight.iloc[i] = daily_weight 
                else:
                    df_weight.iloc[i] = df_weight.iloc[i-1] # 否则延续前一天权重        
            
        return df_weight
        
    @property
    def run(self):
        self.weight = self.get_weight() #计算得到子策略的权重序列
        # self.weighted_return = (self.weight * self.df_return).sum(axis=1) #计算得到最大分散调整之后子策略的权重序列     

def get_mvo_weight(w_return, prev_weight,window=60,n=0):        
    '''
    均值-方差优化
    '''
    rt = w_return.ewm(span=window, adjust=False).mean().iloc[-1].values
    cov = w_return.ewm(span=window, adjust=False).cov().values[-len(rt):]
    obj_func = lambda w: -np.sum(w*rt) + 0.5 * n * np.dot(np.dot(w, cov), w) ## -1 * U(w)
    ## 权重限制
    cons = (
            {'type': 'ineq', 'fun': lambda w: w},             
            # {'type': 'ineq', 'fun': lambda w: 0.4 - w},
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.},
            {'type': 'ineq', 'fun': lambda w: 0.1 - np.sum(np.absolute(w - prev_weight))},
            {'type': 'ineq', 'fun': lambda w: w[0] + w[1] + w[2] + w[3] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - (w[0] + w[1] + w[2] + w[3])}, 
            {'type': 'ineq', 'fun': lambda w: w[4] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - w[4]}, 
            {'type': 'ineq', 'fun': lambda w: w[5] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - w[5]}, 
            {'type': 'ineq', 'fun': lambda w: w[6] + w[7] - 0.15}, 
            {'type': 'ineq', 'fun': lambda w: 0.35 - (w[6] + w[7])}, 
            )
    options = {'maxiter': 1000}
    res = minimize(obj_func, prev_weight, method='SLSQP', constraints=cons, options=options)
    return res.x 


def select_stock(strategy_date, trading_data_num=10, stock_select_num=0, is_local=False, weight=[1.0/7.0]*7, sort_by='Total',version='1.0.3'):
    '''
    作者：丁启恒、李培生
    功能：筛选出适合T0的股票
    '''
    all_stock = all_instruments(type='S',date=strategy_date[0:7])
    all_stock = all_stock[all_stock['Type']=='STOCK']
    stock_list = all_stock['Symbol'].tolist()
    
    starting_date0 = get_previous_trading_date(strategy_date,trading_data_num+1)
    starting_date = get_previous_trading_date(strategy_date,trading_data_num)
    ending_date = get_previous_trading_date(strategy_date,1)
    
    if sort_by=='DailyAmplitude':
        w=[1,0,0,0,0,0,0]
    elif sort_by=='Volume':
        w=[0,1,0,0,0,0,0]
    elif sort_by=='Turnover':
        w=[0,0,1,0,0,0,0]
    elif sort_by=='TurnoverRatio':
        w=[0,0,0,1,0,0,0]
    elif sort_by=='Price':
        w=[0,0,0,0,1,0,0]
    elif sort_by=='CirculatingMarketCap':
        w=[0,0,0,0,0,1,0]
    elif sort_by=='Oscillation':
        w=[0,0,0,0,0,0,1]
    else:
        w=weight
    
    if is_local:
        stock_price=pd.read_csv('stock_price.csv',index_col=0)
        histdate_list0 = []
        for i in range(trading_data_num+1):
            previous_date = get_previous_trading_date(strategy_date,i+1)
            histdate_list0.append(previous_date)
        stock_price = stock_price.loc[stock_price['Clock'].isin(histdate_list0)]
        
        stock_valuation=pd.read_csv('stock_valuation.csv',index_col=0)
        histdate_list = []
        for i in range(trading_data_num):
            previous_date = get_previous_trading_date(strategy_date,i+1)
            histdate_list.append(previous_date)
        stock_valuation = stock_valuation.loc[stock_valuation['Date'].isin(histdate_list)]
        
    else:
        stock_price = get_price(stock_list,starting_date0,ending_date)
        stock_valuation = get_stock_valuation(stock_list,starting_date,ending_date)

    #weekly_result = pd.DataFrame(index=range(len(stock_list)),
    #                    columns=['Symbol', 'Avg_DailyAmplitude', 'Avg_Volume', 'Avg_Turnover', 'Price', 'Avg_TurnoverRatio', 'CirculatingMarketCap', 'Oscillation', 'Is_Limit'])
    weekly_result = pd.DataFrame(index=range(len(stock_list)),
                        columns=['Symbol', 'Avg_DailyAmplitude', 'Avg_Volume', 'Avg_Turnover', 'Price', 'Avg_TurnoverRatio', 'CirculatingMarketCap', 'Oscillation'])
    weekly_result['Symbol'] = stock_list

    stock_price['DailyAmplitude'] = (stock_price['High']-stock_price['Low'])/stock_price['Close'].shift(1)
    stock_price = stock_price.drop(stock_price[stock_price['Clock']==starting_date0].index, axis=0)

    for i in range(len(stock_list)):
        df_price = stock_price[stock_price['Symbol']==stock_list[i]]
        df_valuation = stock_valuation[stock_valuation['Symbol']==stock_list[i]]
    
        weekly_result['Avg_DailyAmplitude'][i] = df_price['DailyAmplitude'].mean()
        weekly_result['Avg_Volume'][i] = df_price['Volume'].mean()
        weekly_result['Avg_Turnover'][i] = df_price['Total_Turnover'].mean()
        weekly_result['Price'][i] = df_price['Close'].mean()
        # weekly_result['Avg_DailyAmplitude'][i] = df_price['DailyAmplitude'].ewm(trading_data_num).mean().iloc[-1]
        # weekly_result['Avg_Volume'][i] = df_price['Volume'].ewm(trading_data_num).mean().iloc[-1]
        # weekly_result['Avg_Turnover'][i] = df_price['Total_Turnover'].ewm(trading_data_num).mean().iloc[-1]
        # weekly_result['Price'][i] = df_price['Close'].ewm(trading_data_num).mean().iloc[-1]
    
        weekly_result['Avg_TurnoverRatio'][i] = df_valuation['TurnoverRatio'].mean()
        weekly_result['CirculatingMarketCap'][i] = df_valuation['CirculatingMarketCap'].mean()
        # weekly_result['Avg_TurnoverRatio'][i] = df_valuation['TurnoverRatio'].ewm(trading_data_num).mean().iloc[-1]
        # weekly_result['CirculatingMarketCap'][i] = df_valuation['CirculatingMarketCap'].ewm(trading_data_num).mean().iloc[-1]
        
        weekly_result['Oscillation'][i] = (((df_price['Close']-df_price['Open']).abs())/(df_price['High']-df_price['Low'])).mean()
        # weekly_result['Oscillation'][i] = (((df_price['Close']-df_price['Open']).abs())/(df_price['High']-df_price['Low'])).ewm(trading_data_num).mean().iloc[-1]
        #weekly_result['Is_Limit'][i] = ( (df_price.iloc[-1]['Close']==df_price.iloc[-1]['Open'])
        #                     & (df_price.iloc[-1]['Close']==df_price.iloc[-1]['High'])
        #                     & (df_price.iloc[-1]['Close']==df_price.iloc[-1]['Low']) ) * 1
    
    weekly_result['Oscillation'].fillna(99999,inplace=True)

    weekly_result['Rank_DailyAmplitude'] = weekly_result['Avg_DailyAmplitude'].rank(method='min')
    weekly_result['Rank_Volume'] = weekly_result['Avg_Volume'].rank(method='min')
    weekly_result['Rank_Turnover'] = weekly_result['Avg_Turnover'].rank(method='min')
    weekly_result['Rank_TurnoverRatio'] = weekly_result['Avg_TurnoverRatio'].rank(method='min')
    weekly_result['Rank_Oscillation'] = (-1*weekly_result['Oscillation']).rank(method='min')

    weekly_result['Dif_Price_l'] = 0
    weekly_result['Dif_Price_u'] = 0
    weekly_result['Dif_Price_l'] = weekly_result['Dif_Price_l'].where(weekly_result['Price']>=7,7-weekly_result['Price'])
    weekly_result['Dif_Price_u'] = weekly_result['Dif_Price_u'].where(weekly_result['Price']<=100,weekly_result['Price']-100)
    weekly_result.sort_values(by=['Dif_Price_l','Dif_Price_u','Price'],ascending=[False,False,True],inplace=True)
    weekly_result['Rank_Price'] = range(len(weekly_result))
    weekly_result['Rank_Price'] = weekly_result['Rank_Price']+1
    weekly_result.sort_index(inplace=True)

    weekly_result['Dif_CirculatingMarketCap_l'] = 0
    weekly_result['Dif_CirculatingMarketCap_u'] = 0
    weekly_result['Dif_CirculatingMarketCap_l'] = weekly_result['Dif_CirculatingMarketCap_l'].where(weekly_result['CirculatingMarketCap']>=30,
                                                                    30-weekly_result['CirculatingMarketCap'])
    weekly_result['Dif_CirculatingMarketCap_u'] = weekly_result['Dif_CirculatingMarketCap_u'].where(weekly_result['CirculatingMarketCap']<=1000,
                                                                    weekly_result['CirculatingMarketCap']-1000)
    weekly_result.sort_values(by=['Dif_CirculatingMarketCap_u','Dif_CirculatingMarketCap_l','CirculatingMarketCap'],ascending=[False,False,False],inplace=True)
    weekly_result['Rank_CirculatingMarketCap'] = range(len(weekly_result))
    weekly_result['Rank_CirculatingMarketCap'] = weekly_result['Rank_CirculatingMarketCap']+1
    weekly_result.sort_index(inplace=True)

    weekly_result['Score_DailyAmplitude'] = (weekly_result['Rank_DailyAmplitude']-1)/(len(weekly_result)-1)*100
    weekly_result['Score_Volume'] = (weekly_result['Rank_Volume']-1)/(len(weekly_result)-1)*100
    weekly_result['Score_Turnover'] = (weekly_result['Rank_Turnover']-1)/(len(weekly_result)-1)*100
    weekly_result['Score_TurnoverRatio'] = (weekly_result['Rank_TurnoverRatio']-1)/(len(weekly_result)-1)*100
    weekly_result['Score_Price'] = (weekly_result['Rank_Price']-1)/(len(weekly_result)-1)*100
    weekly_result['Score_CirculatingMarketCap'] = (weekly_result['Rank_CirculatingMarketCap']-1)/(len(weekly_result)-1)*100
    weekly_result['Score_Oscillation'] = (weekly_result['Rank_Oscillation']-1)/(len(weekly_result)-1)*100
    #weekly_result['Score_IsLimit'] = weekly_result['Is_Limit']*100

    #weekly_result['OriginalTotal_Score'] = (weekly_result['Score_DailyAmplitude']+weekly_result['Score_Volume']+weekly_result['Score_Turnover']
    #                         +weekly_result['Score_TurnoverRatio']+weekly_result['Score_Price']+weekly_result['Score_CirculatingMarketCap']
    #                         +weekly_result['Score_Oscillation']+weekly_result['Score_IsLimit'])/8
    weekly_result['OriginalTotal_Score'] = w[0]*weekly_result['Score_DailyAmplitude']+w[1]*weekly_result['Score_Volume']+w[2]*weekly_result['Score_Turnover']+w[3]*weekly_result['Score_TurnoverRatio']+w[4]*weekly_result['Score_Price']+w[5]*weekly_result['Score_CirculatingMarketCap']+w[6]*weekly_result['Score_Oscillation']
    weekly_result['Total_Score'] = (weekly_result['OriginalTotal_Score']-weekly_result['OriginalTotal_Score'].min())/(weekly_result['OriginalTotal_Score'].max()-weekly_result['OriginalTotal_Score'].min())*100
    #weekly_result.sort_values(by='Total_Score',ascending=False,inplace=True)
    weekly_result['Total_Rank'] = (-1*weekly_result['Total_Score']).rank(method='min')
    weekly_result.sort_values(by=['Total_Rank'],ascending=True,inplace=True)

    if stock_select_num==0:
        #weekly_result_output = weekly_result.loc[:,['Symbol','Avg_DailyAmplitude','Avg_Volume','Avg_Turnover','Price','Avg_TurnoverRatio','CirculatingMarketCap','Oscillation','Is_Limit','Total_Score']]
        weekly_result_output = weekly_result.loc[:,['Symbol','Avg_DailyAmplitude','Avg_Volume','Avg_Turnover','Price','Avg_TurnoverRatio','CirculatingMarketCap','Oscillation','Total_Rank']]
        #weekly_result_output.to_csv('all_stocks.csv')
        return weekly_result_output
    else:
        select_result = weekly_result[0:stock_select_num]
        #select_result_output = select_result.loc[:,['Symbol','Avg_DailyAmplitude','Avg_Volume','Avg_Turnover','Price','Avg_TurnoverRatio','CirculatingMarketCap','Oscillation','Is_Limit','Total_Score']]
        select_result_output = select_result.loc[:,['Symbol','Avg_DailyAmplitude','Avg_Volume','Avg_Turnover','Price','Avg_TurnoverRatio','CirculatingMarketCap','Oscillation','Total_Rank']]
        #select_result_output.to_csv('selected_stocks.csv')
        return select_result_output


def get_future_total_data():
    '''
    作者：谭博文
    获取交易比较活跃的36个商品期货主力连续合约日线行情数据
    '''
    filenames = [ 'R.CN.CZC.AP.0004.csv',
             'R.CN.CZC.CF.0004.csv',
             'R.CN.CZC.FG.0004.csv',
             'R.CN.CZC.MA.0004.csv',
             'R.CN.CZC.OI.0004.csv',
             'R.CN.CZC.RM.0004.csv',
             'R.CN.CZC.SA.0004.csv',
             'R.CN.CZC.SF.0004.csv',
             'R.CN.CZC.SR.0004.csv',
             'R.CN.CZC.TA.0004.csv',
             'R.CN.CZC.ZC.0004.csv',
             'R.CN.DCE.a.0004.csv',
             'R.CN.DCE.c.0004.csv',
             'R.CN.DCE.cs.0004.csv',
             'R.CN.DCE.eg.0004.csv',
             'R.CN.DCE.i.0004.csv',
             'R.CN.DCE.j.0004.csv',
             'R.CN.DCE.jd.0004.csv',
             'R.CN.DCE.jm.0004.csv',
             'R.CN.DCE.l.0004.csv',
             'R.CN.DCE.m.0004.csv',
             'R.CN.DCE.p.0004.csv',
             'R.CN.DCE.pp.0004.csv',
             'R.CN.DCE.v.0004.csv',
             'R.CN.DCE.y.0004.csv',
             'R.CN.SHF.ag.0004.csv',
             'R.CN.SHF.al.0004.csv',
             'R.CN.SHF.au.0004.csv',
             'R.CN.SHF.bu.0004.csv',
             'R.CN.SHF.cu.0004.csv',
             'R.CN.SHF.hc.0004.csv',
             'R.CN.SHF.ni.0004.csv',
             'R.CN.SHF.rb.0004.csv',
             'R.CN.SHF.ru.0004.csv',
             'R.CN.SHF.sp.0004.csv',
             'R.CN.SHF.zn.0004.csv']
    filename = []
    for Name in filenames:
        print(Name[:-4])
        name1 = Name[:-9]
        name2 = name1[9:]
        filename.append(name2)
        globals()["df_"+name2] = get_price(Name[:-4],start_date="2009-01-01")

    df_AP["CLOCK"] = pd.to_datetime(df_AP["CLOCK"]).apply(lambda x:x.date())
    df_AP.set_index("CLOCK",inplace=True)
    total_data = pd.DataFrame(df_AP.stack(),columns=[filename[0]]).unstack()
    for name in filename[1:]:
        print(name)
        temp_data = globals()["df_"+name]
        temp_data["CLOCK"] = pd.to_datetime(temp_data["CLOCK"]).apply(lambda x:x.date())
        temp_data.set_index("CLOCK",inplace=True)
        temp_data = pd.DataFrame(temp_data.stack(),columns=[name]).unstack()
        total_data = total_data.join(temp_data,how="outer")
        
    return total_data


if __name__ == '__main__':
    # 测试
   
    data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\ATBW011.csv")
    data.index = pd.to_datetime(data.level_0)
    test_data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\Balance-20210719.csv")
    result = DrawdownOverlapAnalysis(data.adj_result,StrategyName="ATBW011",test=test_data)
    