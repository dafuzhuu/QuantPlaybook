#从服务器提取原始数据
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import numpy as np
import pandas as pd
import datetime as dt
from causis_api.const import login
import urllib.parse
import matplotlib.pylab as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
import progressbar
username = login.username
password = login.password
version = login.version

common_url = login.common_url + 'option/'
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo

def get_opt_adjust(ProductCode):
    '''
    期权合约调整记录
	ProductCode 合约代码
    '''
    
    url = common_url + 'get_opt_adjust' + common_user \
            + '&productCode=' + ProductCode  
    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    return df

# def get_opt_adjust(ProductCode,start_date,end_date=None):
#     '''
#     期权合约调整记录
# 	ProductCode 合约代码
# 	start_date 开始日期
# 	end_date 截止日期
#     '''
    
#     if end_date == None:
#         today = str(dt.datetime.today())[0:10]
#         today = dt.datetime.strptime(today, '%Y-%m-%d')
#         yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
#         end_date = str(yesterday)[:10]
#     url = common_url + 'get_opt_adjust' + common_user \
#             + '&productCode=' + ProductCode + '&start_date=' + start_date + '&end_date=' + end_date 
#     data = requests.get(url)
#     df = pd.DataFrame.from_dict(data.json()['Data'])
    
#     return df





if __name__ == '__main__':
    # 接口测试
    
    print('ok')
    