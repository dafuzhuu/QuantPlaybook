#从服务器提取原始数据
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import numpy as np
import pandas as pd
import datetime as dt
from causis_api.const import login
import urllib.parse
import matplotlib.pylab as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
import progressbar
username = login.username
password = login.password
version = login.version


common_url = login.common_url + 'etf/'
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo

def get_found_dividend(ProductCode, start_date=None, end_date=None):
    '''
    可转债债券票面利率信息
    ProductCode 合约代码
    start_date 开始日期（利率起始适用日期进行筛选，全部获取不传该项参数）
    end_date 截止日期  （利率结束适用日期进行筛选，全部获取不传该项参数）
    '''
    stock_id = ProductCode
    
    # get方法
    url = common_url + 'get_found_dividend' + common_user \
            + '&productCode=' + stock_id
    if start_date!=None:
        url=f"{url}&start_date={start_date}"
    if end_date!=None:
        url=f"{url}&end_date={end_date}"
    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    return df




if __name__ == '__main__':
    # 接口测试
    print(get_found_dividend('S.CN.SSE.512100','2020-1-1','2023-3-2'))
    