#从服务器提取原始数据并整理成标准格式，方便因子计算
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import pandas as pd
import numpy as np
import datetime as dt
import progressbar
from causis_api.const import login
from causis_api.http_request_handler import HTTPRequestHandler

username = login.username
password = login.password
version = login.version

common_url = login.common_url
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo

def all_instruments_old(type='None', date='None', market='cn'):
    '''
    获取所有合约基础信息
    type: 类型，S代表股票、F代表期货、R代表连续合约、None默认为所有类型、B可转债
    market: 市场，cn默认为中国内地市场
    date: 指定日期，筛选指定日期可交易合约
    返回 dataframe
    '''
    if type == 'S':
        url = common_url + 'get_product' + common_user
    elif type == 'F':
        url = common_url + 'get_product' + common_user + '&type=F'
    elif type == 'R':
        url = common_url + 'get_product' + common_user + '&type=R'
    elif type == 'B':
        url = common_url + 'get_product' + common_user + '&type=B'
    elif type == 'O':
        url = common_url + 'get_product' + common_user + '&type=O'
    elif type == 'None':
        url1 = common_url + 'get_product' + common_user
        url2 = common_url + 'get_product' + common_user + '&type=F'
        url3 = common_url + 'get_product' + common_user + '&type=R'
        url4 = common_url + 'get_product' + common_user + '&type=B'
        resp1 = requests.get(url1)
        resp2 = requests.get(url2)
        resp3 = requests.get(url3)
        resp4 = requests.get(url4)
        df1 = pd.DataFrame.from_dict(resp1.json()['Data'])
        df2 = pd.DataFrame.from_dict(resp2.json()['Data'])
        df3 = pd.DataFrame.from_dict(resp3.json()['Data'])
        df4 = pd.DataFrame.from_dict(resp4.json()['Data'])
        df = pd.concat([df1,df2,df3,df4],axis=0)
        df = df.drop_duplicates()
        df['EndDate'] = df['EndDate'].fillna('2999-12-31')
        df['Type'] = df['Type'].fillna('FUTURE')
        if date == 'None':
            return df
        else:
            df = df[df['BeginDate']<=date]
            df = df[df['EndDate']>=date]
            return df


    resp = requests.get(url)
    df = pd.DataFrame.from_dict(resp.json()['Data'])
    df = df.drop_duplicates()
    df['EndDate'] = df['EndDate'].fillna('2999-12-31')
    df['Type'] = df['Type'].fillna('FUTURE')
    if date == 'None':
        return df
    else:
        df = df[df['BeginDate']<=date]
        df = df[df['EndDate']>=date]
        return df


def all_instruments(type='None', date='None', market='cn'):
    '''
    获取所有合约基础信息
    type: 类型，S代表股票、F代表期货、R代表连续合约、None默认为所有类型、B可转债
    market: 市场，cn默认为中国内地市场
    date: 指定日期，筛选指定日期可交易合约
    返回 dataframe
    '''
    temp_type = type
    if type == 'None':
        temp_type = 'S'
    df=get_instruments(temp_type)
    if type == 'None':
        f_df=get_instruments("F")
        r_df=get_instruments("R")
        b_df=get_instruments("B")
        # o_df=get_instruments("O")
        # o_df=get_instruments("O")
        # df = pd.concat([df,f_df,r_df,b_df,o_df],axis=0)
        df = pd.concat([df,f_df,r_df,b_df],axis=0)
    df = df.drop_duplicates()
    df['EndDate'] = df['EndDate'].fillna('2999-12-31')
    df['Type'] = df['Type'].fillna('FUTURE')
    if date != 'None':
        df = df[df['BeginDate']<=date]
        df = df[df['EndDate']>=date]
    return df

def get_instruments(type):
    res=pd.DataFrame()
    handler = HTTPRequestHandler()
    # resp = handler.get(endpoint='get_product', params={'type': type})
    resp = handler.post(endpoint='get_product', data={'type': type})
    json= handler.process_http_response(resp)
    if json is not None:
        res = pd.DataFrame.from_dict(resp.json()['Data'])
    return res
    

def instruments_old(ProductCode):
    '''
    获取合约详细信息
    '''
    if type(ProductCode) == str:#输入为一只
        stock_id = ProductCode
    elif type(ProductCode) == list:#输入为多只的列表
        stock_id = ','.join(ProductCode) 
    else:                               #输入为index列表或series，都可以转化为list
        ProductCode = ProductCode.tolist()
        stock_id = ','.join(ProductCode)

    url = common_url + 'instruments' + common_user \
            + '&productCode=' + stock_id 
    resp = requests.get(url)
    if resp.status_code == 200:
        df = pd.DataFrame.from_dict(resp.json()['Data'])
        return df
    print(f"resp err:{resp.status_code}")
    return None
    # df = pd.DataFrame.from_dict(resp.json()['Data'])
    # return df

def instruments(ProductCode):
    '''
    获取合约详细信息
    '''
    if type(ProductCode) == str:#输入为一只
        stock_id = ProductCode
    elif type(ProductCode) == list:#输入为多只的列表
        stock_id = ','.join(ProductCode) 
    else:                               #输入为index列表或series，都可以转化为list
        ProductCode = ProductCode.tolist()
        stock_id = ','.join(ProductCode)

    # url = common_url
    handler = HTTPRequestHandler()
    # resp = handler.get(endpoint='instruments', params={'productCode': stock_id})
    resp = handler.post(endpoint='instruments', data={'productCode': stock_id})
    json= handler.process_http_response(resp)
    if json is not None:
        df = pd.DataFrame.from_dict(resp.json()['Data'])
        return df
    return json


def get_price_old(ProductCode, start_date, end_date=None, frequency='day', fields=None, adjust_type=None, skip_suspended =False, market='cn', expect_df=False,use_new=False,trim_begin=False):
    '''
    获取股票历史行情信息
    ProductCode 股票代码
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    frequency 数据频率（day,日频） 
    fields 字段名称（open,close,high等） 
    adjust_type 复权方式（pre\none\post,暂时只支持不复权） 
    skip_suspended 是否跳过停牌日 
    market 证券市场 
    expect_df 是否返回原有的数据结构
    use_new 是否使用新的数据接口
    trim_begin 是否过滤返回数据中头部的空值
    '''
    if type(ProductCode) == str:#输入为一只股票
        stock_id = ProductCode
        n = 0
    else:                       #输入为多只股票
        ProductCode = list(ProductCode)
        n = np.ceil(len(ProductCode) / 50) #向上取整
        stock_id = ','.join(ProductCode[:50])
        
    
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
    
    # data = {'username':username,'password':password,'ProductCode':stock_id,'start_date':start_date,'end_date':end_date}
    # resp = requests.post(url,data=data)
    # df = pd.DataFrame.from_dict(resp.json()['Data'])
    
    str_use_new="false"
    if use_new:
        str_use_new="true"
    str_trim_begin="false"
    if use_new:
        str_trim_begin="true"
    # get方法
    url = common_url + 'get_price' + common_user \
            + '&productCode=' + stock_id + '&start_date=' + start_date + '&end_date=' + end_date + '&useNew=' + str_use_new+ '&trimBegin=' + str_trim_begin

    data = requests.get(url)
    # print(url)
    # print(data.status_code)
    # print(data.text)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    if n <= 1.0:
        return df
    else:
        _pbar = progressbar.ProgressBar(n)
        print('数据下载中……')
        _pbar.start()
        for m in range(1,int(n)):
            stock_id = ','.join(ProductCode[50*m:50*m+50])
            url = common_url + 'get_price' + common_user + '&productCode=' + stock_id + '&start_date=' + start_date + '&end_date=' + end_date+ '&useNew=' + str_use_new+ '&trimBegin=' + str_trim_begin
            data = requests.get(url)
            df_1 = pd.DataFrame.from_dict(data.json()['Data'])
            df = pd.concat([df,df_1],axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('数据下载完成！')
        return df


def get_price(ProductCode, start_date, end_date=None, frequency='day', fields=None, adjust_type=None, skip_suspended =False, market='cn', expect_df=False,use_new=False,trim_begin=False,use_pause=False):
    '''
    获取股票历史行情信息
    ProductCode 股票代码
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    frequency 数据频率（day,日频） 
    fields 字段名称（open,close,high等） 
    adjust_type 复权方式（pre\none\post,暂时只支持不复权） 
    skip_suspended 是否跳过停牌日(暂不支持)
    market 证券市场 (暂时只持仓cn)
    expect_df 是否返回原有的数据结构(暂时不支持其它)
    use_new 是否使用新的数据接口
    trim_begin 是否过滤返回数据中头部的空值
    use_pause 只对股票日行情生效，是否过滤没有停牌信息的股票数据（没有停牌信息的数据是由实时接口返回的为入库数据）
    '''
    is_stock=False
    if type(ProductCode) == str:#输入为一个标的
        stock_id = ProductCode
        if stock_id.startswith("S."):
            is_stock=True
        n = 0
    else:                       #输入为多个标的
        ProductCode = list(ProductCode)
        if ProductCode[0].startswith("S."):
            is_stock=True
        n = np.ceil(len(ProductCode) / 50) #向上取整
        stock_id = ','.join(ProductCode[:50])
        
    
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
    
    str_use_new="false"
    if use_new:
        str_use_new="true"
    str_trim_begin="false"
    if use_new:
        str_trim_begin="true"
    #action设置
    action= f"get_price"
    data = {'productCode':stock_id,'start_date':start_date,'end_date':end_date,'useNew':str_use_new,'trimBegin':str_trim_begin}
        
    handler = HTTPRequestHandler()
    resp = handler.post(endpoint=action, data=data)
    json= handler.process_http_response(resp)
    df=pd.DataFrame()
    if json is not None:
        df = pd.DataFrame.from_dict(json)
    if n>1.0:
        _pbar = progressbar.ProgressBar(n)
        print('数据下载中……')
        _pbar.start()
        for m in range(1,int(n)):
            stock_id = ','.join(ProductCode[50*m:50*m+50])
            data['productCode']=stock_id
            resp = handler.post(endpoint=action, data=data)
            json= handler.process_http_response(resp)
            if json is not None:
                temp_df = pd.DataFrame.from_dict(json)
                df = pd.concat([df,temp_df],axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('数据下载完成！')
    #处理股票日行情无停牌信息数据 
    if is_stock and use_pause and frequency=='day':
        df.dropna(axis=0, subset=['Pause'],inplace=True)
    return  df


def get_trading_dates_old(start_date,end_date=None,productCode='S.CN.SSE.000001'):
    '''
    获取某一时间段的交易日期
    '''
    if end_date == None:
        end_date = str(dt.datetime.today())[:10]
    url = common_url + 'get_trading_date' + common_user \
            + '&productCode=' + productCode + '&start_date=' + start_date + '&end_date=' + end_date
    data = requests.get(url)
    return data.json()['Data']

def get_trading_dates(start_date,end_date=None,productCode='S.CN.SSE.000001'):
    '''
    获取某一时间段的交易日期
    '''
    if end_date == None:
        end_date = str(dt.datetime.today())[:10]
    data = {'productCode':productCode,'start_date':start_date,'end_date':end_date}
    handler = HTTPRequestHandler()
    resp = handler.post(endpoint='get_trading_date', data=data)
    json= handler.process_http_response(resp)
    return json

def get_next_trading_date(date, n, productCode='S.CN.SSE.000001'):
    '''
    获取未来某个交易日
    '''
    data = {'productCode':productCode,'date':date,'count':str(n)}
    handler = HTTPRequestHandler()
    resp = handler.post(endpoint='get_next_trading_date', data=data)
    json= handler.process_http_response(resp)
    return json
   

def get_next_trading_date_old(date, n, productCode='S.CN.SSE.000001'):
    '''
    获取未来某个交易日
    '''
    url = common_url + 'get_next_trading_date' + common_user \
            + '&productCode=' + productCode + '&date=' + date + '&count=' + str(n)
    data = requests.get(url)
    return data.json()['Data']


def get_previous_trading_date(date,n,productCode='S.CN.SSE.000001'):
    '''
    向前获取某个交易日
    '''
    data = {'productCode':productCode,'date':date,'count':str(n)}
    handler = HTTPRequestHandler()
    resp = handler.post(endpoint='get_previous_trading_date', data=data)
    json= handler.process_http_response(resp)
    return json

def get_previous_trading_date_old(date,n,productCode='S.CN.SSE.000001'):
    '''
    获取历史某个交易日
    '''
    url = common_url + 'get_previous_trading_date' + common_user \
            + '&productCode=' + productCode + '&date=' + date + '&count=' + str(n)
    data = requests.get(url)
    return data.json()['Data']

    
def get_trading_hours_old(date,productCode='S.CN.SSE.000001'):
    '''
    获取当日的交易时段
    '''
    url = common_url + 'get_trading_hours' + common_user \
            + '&productCode=' + productCode + '&date=' + date 
    data = requests.get(url)
    series = pd.Series(data.json()['Data'])
    return series

def get_trading_hours(date,productCode='S.CN.SSE.000001'):
    '''
    获取当日的交易时段
    '''
    data = {'productCode':productCode,'date':date}
    handler = HTTPRequestHandler()
    resp = handler.post(endpoint='get_trading_hours', data=data)
    json= handler.process_http_response(resp)
    if json is not None:
        series = pd.Series(json)
        return series
    return json

def get_trading_time_range_old(start_date,end_date,min=60,productCode='S.CN.SSE.000001'):
    '''
    获取连续日期的交易时段
    '''
    url = common_url + 'get_trading_time_range' + common_user \
            + '&productCode=' + productCode + '&start_date=' + start_date + '&end_date=' + end_date + '&min=' + str(min)
    data = requests.get(url)
    series = pd.Series(data.json()['Data'])
    return series

def get_trading_time_range(start_date,end_date,min=60,productCode='S.CN.SSE.000001'):
    '''
    获取连续日期的交易时段
    '''
    data = {'productCode':productCode,'start_date':start_date,'end_date':end_date,'min':str(min)}
    handler = HTTPRequestHandler()
    resp = handler.post(endpoint='get_trading_time_range', data=data)
    json= handler.process_http_response(resp)
    if json is not None:
        series = pd.Series(json)
        return series
    return json

if __name__ == '__main__':
    # 接口测试
    print(all_instruments(date='2020-10-01'))
    print(get_price('S.CN.SZSE.399300','2020-09-11','2020-09-22'))
    print(get_price(['S.CN.SZSE.000001','S.CN.SSE.000001'],'2020-09-11','2020-09-22'))
    print(get_price('S.CN.SZSE.399300','2020-09-21','2020-09-22','minute1'))
    print(get_price('S.CN.SSE.000001','2020-09-21','2020-09-22','minute2'))
    print(get_price('F.CN.SHF.zn.zn2105','2020-09-21','2020-9-25'))
    print(get_price('F.CN.SHF.zn.zn2105','2020-09-21','2020-09-22','minute5'))
    print('2020-09-01')
    