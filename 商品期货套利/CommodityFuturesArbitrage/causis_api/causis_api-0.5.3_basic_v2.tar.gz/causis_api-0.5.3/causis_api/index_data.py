#从服务器提取原始数据并整理成标准格式，方便因子计算
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import pandas as pd
import numpy as np
import datetime as dt
from causis_api.const import login
from causis_api.common_data import all_instruments

username = login.username
password = login.password
version = login.version

common_url = login.common_url + 'stock/'
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo

def index_components(ProductCode, start_date, end_date=None, market='cn'):
    '''
    获取指数成分股信息
    ProductCode 指数代码，只能输入一只
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    market 证券市场
    '''
    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'get_index_weight' + common_user \
            + '&productCode=' + ProductCode + '&start_date=' + start_date + '&end_date=' + end_date 
    data = requests.get(url)
    data_df = pd.DataFrame.from_dict(data.json()['Data'])
    data_df = data_df.set_index(data_df['Date'])
    df = data_df['SymbolWeight']
    components_series = pd.Series(index=df.index)
    for time in df.index:
        components_series.loc[time] = pd.Series(df[time]).index.to_list()
    # url = 'http://cnb2.causis.com.cn:53109/stock/get_index_weight?'
    # data = {'username':'zhangyi','password':'123qwe','productCode':stock_id,'start_date':start_date,'end_date':end_date}
    # resp = requests.post(url,data=data)
    # df = pd.DataFrame.from_dict(resp.json()['Data'])
    
    return components_series

def index_weights(ProductCode, start_date, end_date=None, market='cn'):
    '''
    获取指数成分股权重信息
    ProductCode 指数代码，只能输入一只
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    market 证券市场
    '''
    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'get_index_weight' + common_user \
            + '&productCode=' + ProductCode + '&start_date=' + start_date + '&end_date=' + end_date 
    data = requests.get(url)
    data_df = pd.DataFrame.from_dict(data.json()['Data'])
    if data_df.shape[0] == 0:
        return pd.DataFrame()
    data_df = data_df.set_index(data_df['Date'])
    df = data_df['SymbolWeight']
    stock = all_instruments(type='S')
    stock = stock[stock['Type']=='STOCK']
    all_code = stock['Symbol'].to_list()
    #all_code.append('S.CN.SZSE.000022') # 000022改为001872
    weights_df = pd.DataFrame(index=all_code,columns=df.index)
    for time in df.index:
        xx = pd.Series(df[time])
        yy = xx.apply(lambda x: float(x) if type(x)==str else x) # 源数据的权重为str，转变为float
        yy = yy / yy.sum()
        weights_df.loc[yy.index,time] = yy
    
    return weights_df.dropna(how='all',axis=0)



if __name__ == '__main__':
    # 接口测试
    print(index_components('S.CN.SSE.000016','2020-10-16','2020-10-17'))
    print(index_weights('S.CN.SSE.000016','2020-10-16','2020-10-27'))
    