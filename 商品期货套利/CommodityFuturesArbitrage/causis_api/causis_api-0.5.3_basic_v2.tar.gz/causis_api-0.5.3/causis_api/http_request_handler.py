import requests
import base64
from causis_api.const import *
class HTTPRequestHandler:
    def __init__(self):
        # login.common_url
        self.base_url = login.common_url
        self.session = requests.Session()
        self.auth = None
        username=login.username
        password=login.password
        if username and password:
            credentials = f"{username}:{password}"
            encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
            self.auth = f"Basic {encoded_credentials}"

    def _build_headers(self, headers):
        request_headers = {}
        if self.auth:
            request_headers['Authorization'] = self.auth
        if headers:
            request_headers.update(headers)
        return request_headers

    def get(self, endpoint, headers=None, params=None):
        url = f"{self.base_url}/{endpoint}"
        request_headers = self._build_headers(headers)
        response = self.session.get(url, headers=request_headers, params=params)
        return response

    def post(self, endpoint, headers=None, data=None, json=None):
        url = f"{self.base_url}/{endpoint}"
        request_headers = self._build_headers(headers)
        response = self.session.post(url, headers=request_headers, data=data, json=json)
        return response
    
    def process_http_response(self,response):
        """
        Process the HTTP response and handle errors.
        Parameters:
            response (requests.Response): The response object from the HTTP request.

        Returns:
            dict or None: If the status_code is 200, returns the 'Data' field from the JSON response.
                        Otherwise, returns None and prints the error code and reason.
        """
        if response.status_code == 200:
            return response.json()['Data']
        else:
            print(f"Error: {response.status_code} - {response.reason};{response.text}")
            return None

    # 添加其他HTTP方法的处理函数，如PUT、DELETE等

# 示例使用：
if __name__ == "__main__":
    # 创建HTTP请求处理类实例
    handler = HTTPRequestHandler()

    # 发送GET请求
    response_get = handler.get(endpoint='resource', params={'param1': 'value1', 'param2': 'value2'})
    if response_get.status_code == 200:
        print("GET请求成功！")
        print(response_get.json())
    else:
        print(f"GET请求失败：{response_get.status_code}")

    # 发送POST请求
    data = {'key1': 'value1', 'key2': 'value2'}
    response_post = handler.post(endpoint='resource', json=data)
    if response_post.status_code == 201:
        print("POST请求成功！")
        print(response_post.json())
    else:
        print(f"POST请求失败：{response_post.status_code}")
