#从服务器提取原始数据
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import numpy as np
import pandas as pd
import datetime as dt
from causis_api.const import login
import urllib.parse
import matplotlib.pylab as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
import progressbar
username = login.username
password = login.password
version = login.version

common_url = login.common_url + 'bond/'
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo

def get_bond_daily_convert(ProductCode,start_date,end_date=None):
    '''
    可转债每日转股统计，从2000-7-12开始
    返回dataframe，包括日期、代码、内部编码
	ProductCode 合约代码
	start_date 开始日期
	end_date 截止日期
    '''
    
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
    url = common_url + 'get_bond_daily_convert' + common_user \
            + '&productCode=' + ProductCode + '&start_date=' + start_date + '&end_date=' + end_date 
    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    return df



def get_bond_price_adjust(ProductCode, start_date, end_date=None,is_pub='true'):
    '''
    可转债转股价格调整
    ProductCode 合约代码
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期 
    '''
    stock_id = ProductCode
    
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
        # end_date = today
    
    # get方法
    url = common_url + 'get_bond_price_adjust' + common_user \
            + '&productCode=' + stock_id + '&start_date=' + start_date + '&end_date=' + end_date + '&is_pub=' + is_pub 
    
    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    return df


def get_bond_coupon(ProductCode, start_date=None, end_date=None):
    '''
    可转债债券票面利率信息
    ProductCode 合约代码
    start_date 开始日期（利率起始适用日期进行筛选，全部获取不传该项参数）
    end_date 截止日期  （利率结束适用日期进行筛选，全部获取不传该项参数）
    '''
    stock_id = ProductCode
    
    # get方法
    url = common_url + 'get_bond_coupon' + common_user \
            + '&productCode=' + stock_id
    if start_date!=None:
        url=f"{url}&start_date={start_date}"
    if end_date!=None:
        url=f"{url}&end_date={end_date}"
    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    return df




if __name__ == '__main__':
    # 接口测试
    
    data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\ATBW011.csv")
    data.index = pd.to_datetime(data.level_0)
    test_data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\Balance-20210719.csv")
    # result = DrawdownOverlapAnalysis(data.adj_result,StrategyName="ATBW011",test=test_data)
    