#TableMath package setup
#Causis Investment
#
#TableMath Python 包 1.1.3.1
#Python 3.8

import os
import setuptools
#需要在Anaconda Prompt 中到文件目录中执行   python setup.py sdist   
setuptools.setup(
    name="causis_api", 
    version="0.5.3", 
    #description="2D array math library with (STL, QP), .Net Standard 2.0, Windows 64x,Causis Investment",
   # author="Cai,Xiaoyu",
    #author_email="xiaoyu.cai@causis.com.cn",
    platforms='any',
    packages=  setuptools.find_packages(),
    install_requires = ['numpy'],
    classifiers=[
        'Operating System :: Microsoft :: Windows',
        'Programming Language :: Python :: 3'
    ],
    include_package_data = True
    )
